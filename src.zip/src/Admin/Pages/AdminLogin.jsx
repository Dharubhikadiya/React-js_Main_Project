import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'

function AdminLogin() {

    const navigate = useNavigate();
    const [email,setEmail] = useState("");
    const [password,setPassword] = useState("");
    const [role,setRole] = useState("");
    const [admin,setAdmin] = useState({});

    const handlesubmit = () => {
        axios.get(`http://localhost:8000/users?email=${email}&password=${password}&role=${admin}`)
        .then((res)=>{
            if(res.data){
                localStorage.getItem('adminuser',JSON.stringify(res.data[1]));
                navigate('/admin/dashboard');
            }else{
                alert("email & password is not valid")
            }
        }).catch((err)=>{
            console.log(err);
            return false;
        });
    }

    useEffect(()=>{
        let data = JSON.parse(localStorage.getItem('adminuser'));
        if(data){
            navigate('/admin/dashboard')
        }
        setAdmin(data)
    },[])

  return (
        <div>
        <h1 className='pt-5 text-center'>My account</h1>
        <div className='d-flex text-center justify-content-center align-items-center text-secondary'>
            <p>Home</p>
            <i class="bi bi-dot pb-3 fs-3"></i>
            <p>My account</p>
        </div>
            <div className='container d-flex justify-content-center align-items-center mt-4'>
              
                <div className='loginform shadow p-3 mb-5 bg-body pb-4'>
                    <h3 className='text-center pt-5'>Login to Shofy.</h3>
                    <div className='d-flex text-center justify-content-center align-items-center text-secondary'>
                        <p>Don’t have an account?</p>
                        <p >
                        <Link to={`/admin/register`} className='text-decoration-none ps-2'>Create a free account</Link></p>
                    </div>
                    <div className='d-flex justify-content-center align-items-center my-3'>
                        <div className='icons border py-3 px-5'>
                            <img src='https://shofy-nuxt.vercel.app/img/icon/login/google.svg' className='pe-2'></img>
                            Sign in with google
                        </div>
                        <div className='icons border py-3 px-4 mx-3'>
                            <img src='https://shofy-nuxt.vercel.app/img/icon/login/facebook.svg' className=''></img>
                        </div>
                        <div className='icons border py-3 px-4'>
                            <img src='https://shofy-nuxt.vercel.app/img/icon/login/apple.svg' className=''></img>
                        </div>
                    </div>
                    <div className='d-flex justify-content-center align-items-center mb-5'>
                        <span className='text-secondary'>-------------------</span>
                        <p className='mx-3 text-secondary mb-0'>or Sign in with Email</p>
                        <span className='text-secondary'>-------------------</span>
                    </div>
                    <div class="input-box d-flex justify-content-center align-items-center my-3 mb-5">
                        <label class="input-label px-1 fs-6">Your Email</label>
                        <input type="email" name='email' onChange={(e)=>setEmail(e.target.value)} value={email} placeholder='shofy@mail.com' className="p-3 pt-3 w-75 border" onfocus="setFocus(true)" onblur="setFocus(false)" />
                    </div>
                    <div class="input-box d-flex justify-content-center align-items-center my-4">
                        <label class="input-label px-1">Password</label>
                        <input type="password" name='password' onChange={(e)=>setPassword(e.target.value)} value={password} placeholder='Min. 6 character' className="p-3 w-75 border" onfocus="setFocus(true)" onblur="setFocus(false)" />
                    </div>
                   {
                //     <div className='d-flex mb-4'>
                //     <select name='role' onChange={ (e) => setRole(e.target.value) } value={role} className='w-25 form-control'>
                //         <option>Choose the role</option>
                //         <option value="admin">admin</option>
                //         <option value="user">user</option>
                //     </select>
                // </div>
                   }
                    <Link to='/admin/register'>
                    <div className='d-flex justify-content-center align-items-centerx'>
                    <button onClick={()=>handlesubmit()} type="button" className='button border border-secondary text-center fs-6 w-75 py-3 fw-bold mb-5 mt-3'>Login </button>
                </div>
                    </Link>
                </div>
            </div>
            <button><Link to='/admin'></Link></button>
        </div>
  )
}

export default AdminLogin